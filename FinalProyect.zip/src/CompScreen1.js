import React, { useContext, useEffect, useState } from 'react';
import { Button, View,BackHandler, Text,Platform,StyleSheet, Image } from 'react-native';
import { Contexlocalisation } from '../App';

const CompScreen1=({navigation})=> {  
    
    const {value2,setValue2}=useContext(Contexlocalisation); //contex
    const [osInRuning,setOsInRunning]=useState("");
    const startImage= require('./thunder22.jpg');
       
    useEffect(() => {
        platformCheck();
    }, []);
    //Function check plataform
    function platformCheck(){
        switch(Platform.OS){
            case "web":
                setOsInRunning(" Web ");
                //alert("web not suported ");
                break;
            case "android":
                setOsInRunning(" Android ");
                //BackHandler.exitApp(); //this hook works only in android
                break;
            case "ios":
                setOsInRunning(" Ios ");
                alert("IOS not suported ");
                //RNExitApp.exitApp();//close App from IOS , this works only in IOS
                break;
            case "macos":
                setOsInRunning(" Mac OS ");
                break;
            default: setOsInRunning(" Unknown ");
        }
    }
    return (
     <View style={styles.container}>
        <View style={styles.container2Text}>
            <Text style={{color:'#ffecd1'}}> ON CATCH: {value2} </Text>
        </View>
        <View style={styles.container2Text} >
            <Text style={{color:'#ffecd1'}}> App - Is running on: {osInRuning}</Text>
        </View>    
        <Image style={styles.startImageS} source={startImage} />
        <View style={styles.containerStartButtom}>
            <Button color="#ff7d00" title="Start" onPress={ ()=> navigation.navigate("Start")} />
        </View>    
      </View>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#78290f",
        alignItems: "center",
        justifyContent: "top",
    },
    container2Text: {
        justifyContent: "center", 
        padding:"10px"
    },
    startImageS: {
        width : '300px',
        height: '420px',
        borderRadius:'30%',
        borderColor:'black',
        borderWidth:'12px',
    },
    containerStartButtom: {
        backgroundColor:"#78290f",
        justifyContent:'center' ,
        padding:'25px', //araund area
        width: "80%", //Bottom size
    },
});
export default CompScreen1;