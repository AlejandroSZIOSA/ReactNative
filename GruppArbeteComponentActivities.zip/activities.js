
import React, { useState } from 'react';
import { FlatList, ScrollView,ImageBackground, StyleSheet, Text, View, Button } from 'react-native';

const Activities = () => {
    const imageDice = { uri: "https://www.slashgear.com/wp-content/uploads/2019/04/black-hole-1280x720.jpg" };
    const imageZudoku= { uri: " https://miro.medium.com/max/700/1*r6jPFRnbQT5piygwvPXu_w.jpeg" };
    const imageLigths= { uri: " https://t2.uc.ltmcdn.com/images/9/1/7/img_42719_apa_276365_600.jpg" };   
    const onecolorbackground= { uri: "  " };   
    //https://www.slashgear.com/wp-content/uploads/2019/04/black-hole-1280x720.jpg
    //https://i.pinimg.com/564x/ae/9a/f5/ae9af5a0886a662316706124a062f025.jpg
    //https://miro.medium.com/max/700/1*r6jPFRnbQT5piygwvPXu_w.jpeg                                     
    
    const[eventList,updateEventList]=useState(["A Crazy Lucky Dice / 01-12 / 14:40-21:00",
    "Sudoku Fight / 05-12 / 16:00-21:00","Sudoku Fight / 10-12 / 16:00-21:00","A Crazy Lucky Dice / 15-12 / 16:00-21:00"]);
    const[array,setArray]=useState(eventList);
    
    return (
    <View style={styles.containerActivities}>
       <Text style={styles.header} >CYBER ACTIVITIES </Text>    
        <View>
            
            <View> 
                
                <ImageBackground source={imageLigths} resizeMode="stretch" style={styles.image}>   
                <Text style={styles.header2}> ONLINE CRAZY GAMES IN DECEMBER 2021  </Text>  
                </ImageBackground>              
                
                   <View> 
                    <Text style={styles.gamesText}>GAME 1 * A CRAZY LUCKY DICE * [A LUCKY GAME]</Text>   
                                           
                            <View >   
                            <ImageBackground source={imageDice} resizeMode="containe" style={styles.image}>   
                            <Text style={styles.description}>Description: The Winner will be the player 
                            how have max score.If there are two or more winners so total reward will be divided.
                            If in 
                            one ROUND player dices match so game restart inclusive total points.{'\n'} 
                            ----------------------{'\n'}
                            MAX PLAYERS=5{'\n'}
                            MAX ROUNDS=10{'\n'}
                            CURRENCY=ACEPTED{'\n'}  
                            ----------------------{'\n'}                                                    
                            </Text>
                            </ImageBackground>   
                            </View>
                    </View> 
                    <View>
                    <Text style={styles.gamesText}>GAME 2 * SUDOKU FIGHT * [A SPEED GAME] </Text>   
                            <View>      
                            <ImageBackground source={imageZudoku} resizeMode="cover" style={styles.image}>
                            <Text style={styles.description}>Description: Winner will be
                            how match max correct tries. If there are
                            two or more winners so total reward will be divided.{'\n'}
                            -------------------------{'\n'}
                            MAX PLAYERS=4{'\n'}
                            ROUNDS=3{'\n'}
                            SUDOKU LEVEL=EXPERT{'\n'}
                            CURRENCY= ACEPTED{'\n'}       
                            -------------------------{'\n'}                                              
                            </Text>
                            </ImageBackground>
                            </View> 
                    </View>
            </View>
        </View>
        <View >
            <ImageBackground source={imageLigths} resizeMode="cover" style={styles.image}>  
            <Text style={styles.header2}> Calender  </Text>
            </ImageBackground>
        </View>
        <FlatList      
        List
        data={eventList}
        renderItem={ (   {item,index } ) =>   (
                <View style={styles.flatItem}>            
               <Text>   {item}  </Text>
               <Button  title="Reserve this event"> </Button>
               </View>
        )} />
    </View>
);
   };
const styles = StyleSheet.create({
    containerActivities: {
        flex: 1,
        backgroundColor: 'black',
        alignItems: 'center',
        justifyContent: 'center',
        textAlign:'center',
    },
    header: {
        //backgroundColor: 'white',
        color: 'red',
        textAlign: 'center',
        fontSize:'x-large',
        height:'40px'
    },
        header2:{
        color: 'white',    
        //backgroundColor: 'black',
        fontSize:'large',
        height:'50px'
    },
    description: {
        color:'yellow',
        textAlign:'left',
        fontSize:'normal',
    },
    gamesText:{
        color:'red',
        fontSize:'normal',
        height:'30px'
    },
    flatItem: {
        backgroundColor: '#f9c2ff',
        padding: 5,
        marginVertical: 8,
        marginHorizontal: 16,
        fontSize:'litle',
    //height:'20px',
    },
        image: {
        flex: 1,
        justifyContent: "center"
    },
});
export default Activities;
